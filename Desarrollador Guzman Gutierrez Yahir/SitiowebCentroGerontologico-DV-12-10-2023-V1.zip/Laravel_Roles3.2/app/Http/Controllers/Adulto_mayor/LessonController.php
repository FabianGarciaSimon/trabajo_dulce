<?php

namespace App\Http\Controllers\Adulto_mayor;

use Laravel\Fortify\Http\Controllers\AuthenticatedSessionController;

use App\Http\Controllers\Controller;
use App\Models\User;

use Illuminate\Http\Request;

class LessonController extends AuthenticatedSessionController
{

    public function index()
    {
        return view('adulto_mayor.lessons.index');
    }
}
