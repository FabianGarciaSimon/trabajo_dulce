<div class="flex items-center">  
  <div class="ml-auto">
      <img src="<?php echo e(asset('storage/logo/logo2.png')); ?>" alt="Logo" class="h-10 w-30" />
  </div>
</div><?php /**PATH C:\xampp\htdocs\Proyectos_laravel\Prof_Dulce\Laravel_Roles3.1\resources\views/vendor/jetstream/components/application-mark.blade.php ENDPATH**/ ?>