<?php if($errors->any()): ?>
    <div <?php echo e($attributes); ?>>
        

        <ul class="mt-3 list-none text-sm space-y-2">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="bg-red-100 border-l-4 border-red-600 text-red-600 font-bold p-1"><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Proyectos_laravel\Prof_Dulce\Laravel_Roles3.2\resources\views/vendor/jetstream/components/validation-errors.blade.php ENDPATH**/ ?>