<a href="/">
    <div class="flex items-center">  
        <div class="ml-auto">
            <img src="<?php echo e(asset('storage/logo/logo2.png')); ?>" alt="Logo" class="h-20 w-30" />
        </div>
    </div>
</a>
<?php /**PATH C:\xampp\htdocs\Proyectos_laravel\Laravel_Roles2.0\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>