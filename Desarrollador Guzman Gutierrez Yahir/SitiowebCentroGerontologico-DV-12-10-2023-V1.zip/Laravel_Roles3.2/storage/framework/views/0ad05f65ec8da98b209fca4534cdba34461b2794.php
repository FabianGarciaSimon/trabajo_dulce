<div class="flex items-center">  
  <div class="ml-auto">
      <img src="<?php echo e(asset('storage/logo/logo2.png')); ?>" alt="Logo" class="h-20 w-30" />
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\Proyectos_laravel\Laravel_Roles2.0\resources\views/vendor/jetstream/components/application-logo.blade.php ENDPATH**/ ?>