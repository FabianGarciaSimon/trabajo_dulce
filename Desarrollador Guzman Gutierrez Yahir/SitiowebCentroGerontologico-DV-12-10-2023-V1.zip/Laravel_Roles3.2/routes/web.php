<?php

use App\Http\Controllers\HomeController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Adulto_mayor\LessonController;
use Laravel\Fortify\src\Http\Controllers\AuthenticatedSessionController;
use Laravel\Fortify\src\Http\Controllers\AdultoMayorLoginController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

// Ruta para buscar por número en el registro
Route::get('/buscarNumero/{numero}', [LessonController::class, 'buscarNumero']);

// Para actualizar los datos del registro
Route::post('/actualizarRegistro', 'LessonController@actualizarRegistro')->name('actualizar.registro');

Route::middleware(['auth:sanctum', 'verified'])->get('/dashboard', function () {
    return view('dashboard');
})->name('dashboard');

Route::group(['middleware' => 'auth'], function () {
    Route::group(['middleware' => 'role:adulto_mayor', 'prefix' => 'adulto_mayor', 'as' => 'adulto_mayor.'], function () {
        Route::resource('lessons', \App\Http\Controllers\Adulto_mayor\LessonController::class);
    });
    Route::group(['middleware' => 'role:doctor', 'prefix' => 'doctor', 'as' => 'doctor.'], function () {
        Route::resource('servicios', \App\Http\Controllers\Doctores\ServiciosController::class);
    });
    Route::group(['middleware' => 'role:admin', 'prefix' => 'admin', 'as' => 'admin.'], function () {
        Route::resource('users', \App\Http\Controllers\Admin\UserController::class);
    });
});

// Ruta de inicio de sesión para adultos mayores
Route::get('/login/adulto-mayor', [App\Http\Controllers\AdultoMayorLoginController::class, 'index'])
    ->middleware(['guest'])
    ->name('login.adulto-mayor');

// Route::get('/login/adulto-mayor', [Adulto_mayor\LessonController::class, 'showLoginForm'])
//     ->middleware(['guest'])
//     ->name('login.adulto-mayor');
